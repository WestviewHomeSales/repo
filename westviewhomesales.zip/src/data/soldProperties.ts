import { Property } from '../types/property';

export const soldProperties: Property[] = [];
